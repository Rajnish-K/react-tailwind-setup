import { defineConfig } from 'vite'
import path from 'path'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          react: ["react", "react-dom", "react-router-dom"],
          redux: ["@reduxjs/toolkit", "react-redux"],
          ui: [
            "@radix-ui/react-dialog",
            "@radix-ui/react-dropdown-menu",
            "@radix-ui/react-popover",
            "lucide-react"
          ],
          forms: ["react-hook-form", "zod"],
          utils: ["axios", "dayjs", "lodash"],
        },
      },
    },
  },
  plugins: [tailwindcss(), react()],
   optimizeDeps: {
    include: [
      './src/locales/en/translation.json',
      './src/locales/fr/translation.json'
    ]
  },
  define: {
__APP_ENV__: JSON.stringify(process.env.APP_ENV || 'development'),
  },
   resolve: {
     alias: {
      "@": path.resolve(__dirname, "./src"),
      // "@components": path.resolve(__dirname, "./src/components"),

    },
  },
})
