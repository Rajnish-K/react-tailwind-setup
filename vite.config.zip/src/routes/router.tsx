// routes.tsx
import { createBrowserRouter } from "react-router-dom";
import { Layout } from "../components/Layout";
import Login from "../components/pages/auth/Login";
import Register from "../components/pages/auth/Register";
import ForgotPassword from "../components/pages/auth/ForgotPassword";
import Dashboard from "../components/pages/dashboard/Dashboard";
import { ProtectedRoute } from "./ProtectedRoute";
import FormWithDatePickers from "../components/module1/FormWithDatePickers";
import ComplexForm from "../components/module1/ComplexForm";
import MaterialOfferingInspectionRegister from "../components/complex_form/MaterialOfferingInspectionRegister";
import MaterialOfferingInspectionRegisterWithFileUpload from "../components/complex_form/MaterialOfferingInspectionRegisterWithFileUpload";
import RDSOInspectionNotesComplianceRegiste from "../components/complex_form/RDSOInspectionNotesComplianceRegiste";
import EmployeePage from "../components/pages/employee/EmployeePage";
import CreateEmployee from "../components/pages/employee/CreateEmployee";
import EditEmployee from "../components/pages/employee/EditEmployee";
import ViewEmployee from "../components/pages/employee/ViewEmployee";
// appRoutes.ts
// import { Navigate } from "react-router-dom";

export interface AppRoute {
  path?: string;
  index?: boolean;
  label?: string;
  element?: React.ReactNode;
  showInMenu?: boolean;
  children?: AppRoute[];
}

// routerConfig.tsx
import { Navigate } from "react-router-dom";
import UserFormCustomValidation from "../components/module1/UserFormCustomValidation";

export const routerConfig = [
  /* ================= PUBLIC ================= */
  {
    path: "/",
    element: <Login />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/forgot-password",
    element: <ForgotPassword />,
  },

  /* ================= PROTECTED ================= */
  {
    path: "/app",
    element: (
      <ProtectedRoute>
        <Layout />
      </ProtectedRoute>
    ),
    children: [
      /* ================= ESS ================= */
      {
        path: "ess",
        label: "ESS",
        showInMenu: true,
        children: [
          {
            index: true,
            element: <Dashboard />,
          },
          {
            path: "home",
            label: "Home",
            element: <FormWithDatePickers />,
            showInMenu: true,
          },
           {
            path: "customformvalidation",
            label: "Custom Form Validation",
            element: <UserFormCustomValidation />,
            showInMenu: true,
          },
          
        ],
      },

      /* ================= HRMS ================= */
      {
        path: "hrms",
        label: "HRMS",
        showInMenu: true,
        children: [
          {
            index: true,
            element: <Dashboard />,
          },
          {
            path: "home",
            label: "Home",
            element: <ComplexForm />,
            showInMenu: true,
          },
          {
            path: "bonafide",
            label: "Bonafide",
            showInMenu: true,
            children: [
              {
                index: true,
                element: <Navigate to="configure" replace />,
              },
              {
                path: "configure",
                label: "Configure Bonafide",
                element: <MaterialOfferingInspectionRegister />,
                showInMenu: true,
                children: [
                  {
                    path: "create",
                    label: "Create New Bonafide",
                    element: <MaterialOfferingInspectionRegisterWithFileUpload />,
                    showInMenu: false,
                  },
                  {
                    path: "view/:id",
                    label: "View Bonafide",
                    element: <RDSOInspectionNotesComplianceRegiste />,
                    showInMenu: false,
                  },
                ],
              },
            ],
          },
        ],
      },

      /* ================= ADMIN ================= */
      {
        path: "admin",
        label: "Admin",
        showInMenu: true,
        children: [
          {
            index: true,
            element: <Dashboard />,
          },
          {
            path: "home",
            label: "Home",
            element: <Dashboard />,
            showInMenu: true,
          },
          {
            path: "visitor",
            label: "Visitor",
            showInMenu: true,
            children: [
              {
                index: true,
                element: <Navigate to="manage" replace />,
              },
              {
                path: "manage",
                label: "Manage Visitor",
                element: <EmployeePage />,
                showInMenu: true,
                children: [
                  {
                    path: "addEmployee",
                    label: "Add New Visitor",
                    element: <CreateEmployee />,
                    showInMenu: false,
                  },
                  {
                    path: "EditEmployee/:id",
                    label: "Add New Visitor",
                    element: <EditEmployee />,
                    showInMenu: false,
                  },
                  {
                    path: "viewEmployee/:id",
                    label: "Add New Visitor",
                    element: <ViewEmployee />,
                    showInMenu: false,
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
];




// router.ts
// import { createBrowserRouter } from "react-router-dom";
// import { appRoutes } from "./appRoutes";
// buildRoutes.ts
export const buildRoutes = (routes: any[]): any[] =>
  routes.map(({ path, index, element, children }) => ({
    path,
    index,
    element,
    children: children ? buildRoutes(children) : undefined,
  }));

  console.log("Built Routes:", buildRoutes(routerConfig));

export const router = createBrowserRouter(buildRoutes(routerConfig));




// export const router = createBrowserRouter(routerConfig);
