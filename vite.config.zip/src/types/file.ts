// types/file.ts
export interface ApiFile {
  fileId: number;
  fileName: string;
  fileUrl?: string; // optional for view
}

export interface LocalFile {
  tempId: string;
  file: File;
}

export type AttachmentItem =
  | { type: "api"; data: ApiFile }
  | { type: "local"; data: LocalFile };

  