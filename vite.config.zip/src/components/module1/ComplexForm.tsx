import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import { FileUploadField } from "../common_components/FileUploadField";

// Define the Zod schema
const formSchema = z.object({
  personalInfo: z.object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    phone: z.string().min(10, "Phone number must be at least 10 digits"),
      email: z.string().email("Invalid email address").or(z.literal("")),
    phoneType: z.enum(["mobile", "home", "work"]),
    // dateOfBirth: z.string().min(1, "Date of birth is required"),
    // gender: z.enum(["male", "female", "other", "prefer-not-to-say"]),
    // nationality: z.string().min(1, "Nationality is required"),
  }),
//   contactInfo: z.object({
//     email: z.string().email("Invalid email address"),
//     phone: z.string().min(10, "Phone number must be at least 10 digits"),
//     phoneType: z.enum(["mobile", "home", "work"]),
//     preferredContact: z.enum(["email", "phone"]),
//   }),
//   address: z.object({
//     street: z.string().min(1, "Street address is required"),
//     city: z.string().min(1, "City is required"),
//     state: z.string().min(1, "State is required"),
//     zipCode: z.string().min(5, "Zip code must be at least 5 digits"),
//     country: z.string().min(1, "Country is required"),
//   }),
  emergencyContacts: z.array(
    z.object({
      name: z.string().min(1, "Emergency contact name is required"),
      relationship: z.string().min(1, "Relationship is required"),
      phone: z.string().min(10, "Phone number must be at least 10 digits"),
      email: z.string().email("Invalid email address").or(z.literal("")),
    })
  ).min(1, "At least one emergency contact is required"),

  attachments: z
  .array(
    z.object({
      file: z.instanceof(File),
      name: z.string(),
      size: z.number(),
      type: z.string(),
    })
  )
  .min(1, "At least one file is required"),

//   education: z.array(
//     z.object({
//       institution: z.string().min(1, "Institution name is required"),
//       degree: z.string().min(1, "Degree is required"),
//       fieldOfStudy: z.string().min(1, "Field of study is required"),
//       startDate: z.string().min(1, "Start date is required"),
//       endDate: z.string().optional().or(z.literal("")),
//       currentlyEnrolled: z.boolean(),
//     })
//   ).min(1, "At least one education entry is required"),
//   employment: z.array(
//     z.object({
//       company: z.string().min(1, "Company name is required"),
//       position: z.string().min(1, "Position is required"),
//       startDate: z.string().min(1, "Start date is required"),
//       endDate: z.string().optional().or(z.literal("")),
//       currentlyEmployed: z.boolean(),
//       description: z.string().min(1, "Description is required"),
//     })
//   ).min(1, "At least one employment entry is required"),
//   skills: z.array(
//     z.object({
//       name: z.string().min(1, "Skill name is required"),
//       level: z.enum(["beginner", "intermediate", "advanced", "expert"]),
//       yearsOfExperience: z.number().min(0, "Years of experience cannot be negative"),
//     })
//   ).min(1, "At least one skill is required"),
//   preferences: z.object({
//     newsletter: z.boolean(),
//     notifications: z.boolean(),
//     marketingEmails: z.boolean(),
//     theme: z.enum(["light", "dark", "auto"]),
//     language: z.enum(["en", "es", "fr", "de"]),
//   }),
  termsAccepted: z.boolean().refine(val => val === true, "You must accept the terms"),
  privacyAccepted: z.boolean().refine(val => val === true, "You must accept the privacy policy"),
});

type FormData = z.infer<typeof formSchema>;

export default function ComplexForm() {
  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting, isValid },
    watch,
    setValue,
    trigger,
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    mode: "onChange",
    reValidateMode: "onChange",
    defaultValues: {
      personalInfo: {
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        phoneType: "home"
      },
    //   contactInfo: {
    //     email: "",
    //     phone: "",
    //     phoneType: "mobile",
    //     preferredContact: "email",
    //   },
    //   address: {
    //     street: "",
    //     city: "",
    //     state: "",
    //     zipCode: "",
    //     country: "",
    //   },
      emergencyContacts: [
        {
          name: "",
          relationship: "",
          phone: "",
          email: "",
        },
      ],
      attachments: [],
    //   education: [
    //     {
    //       institution: "",
    //       degree: "",
    //       fieldOfStudy: "",
    //       startDate: "",
    //       endDate: "",
    //       currentlyEnrolled: false,
    //     },
    //   ],
    //   employment: [
    //     {
    //       company: "",
    //       position: "",
    //       startDate: "",
    //       endDate: "",
    //       currentlyEmployed: false,
    //       description: "",
    //     },
    //   ],
    //   skills: [
    //     {
    //       name: "",
    //       level: "intermediate",
    //       yearsOfExperience: 0,
    //     },
    //   ],
    //   preferences: {
    //     newsletter: false,
    //     notifications: true,
    //     marketingEmails: false,
    //     theme: "auto",
    //     language: "en",
    //   },
      termsAccepted: false,
      privacyAccepted: false,
    },
  });

  const {
    fields: emergencyContactFields,
    append: appendEmergencyContact,
    remove: removeEmergencyContact,
  } = useFieldArray({
    control,
    name: "emergencyContacts",
  });

  // const {
  //   fields: educationFields,
  //   append: appendEducation,
  //   remove: removeEducation,
  // } = useFieldArray({
  //   control,
  //   name: "education",
  // });

  // const {
  //   fields: employmentFields,
  //   append: appendEmployment,
  //   remove: removeEmployment,
  // } = useFieldArray({
  //   control,
  //   name: "employment",
  // });

  // const {
  //   fields: skillFields,
  //   append: appendSkill,
  //   remove: removeSkill,
  // } = useFieldArray({
  //   control,
  //   name: "skills",
  // });


  console.log("Errors:", watch());

  const onSubmit = (data: FormData) => {
    console.log("Form submitted:", data);
    alert("Form submitted successfully!");
  };

  // Handle checkbox changes with validation trigger
  const handleCheckboxChange = (field: any, checked: boolean) => {
    setValue(field, checked);
    trigger(field);
  };

  // Handle array field changes with validation
  const handleArrayFieldChange = (name: any, index: number, value: any) => {
    setValue(name, value);
    trigger(name);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold text-center">Complex Form</h1>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Enter your personal details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  {...register("personalInfo.firstName")}
                  placeholder="Enter first name"
                />
                {errors.personalInfo?.firstName && (
                  <p className="text-red-500 text-sm mt-1">{errors.personalInfo.firstName.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  {...register("personalInfo.lastName")}
                  placeholder="Enter last name"
                />
                {errors.personalInfo?.lastName && (
                  <p className="text-red-500 text-sm mt-1">{errors.personalInfo.lastName.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                {...register("personalInfo.email")}
                placeholder="Enter email address"
              />
              {/* {errors.contactInfo?.email && (
                <p className="text-red-500 text-sm mt-1">{errors.contactInfo.email.message}</p>
              )} */}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...register("personalInfo.phone")}
                  placeholder="Enter phone number"
                />
                {/* {errors.contactInfo?.phone && (
                  <p className="text-red-500 text-sm mt-1">{errors.contactInfo.phone.message}</p>
                )} */}
              </div>

              <div>
                <Label htmlFor="phoneType">Phone Type</Label>
                <Select
                  onValueChange={(value) => {
                    setValue("personalInfo.phoneType", value as any);
                    trigger("personalInfo.phoneType");
                  }}
                  defaultValue={watch("personalInfo.phoneType")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select phone type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mobile">Mobile</SelectItem>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="work">Work</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardHeader>
            <CardTitle>Emergency Contacts</CardTitle>
            <CardDescription>Add at least one emergency contact</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {emergencyContactFields.map((field, index) => (
              <div key={field.id} className="p-4 border rounded-lg space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-semibold">Contact #{index + 1}</h3>
                  {index > 0 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeEmergencyContact(index)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`emergencyContacts.${index}.name`}>Name *</Label>
                    <Input
                      {...register(`emergencyContacts.${index}.name` as const)}
                      placeholder="Full name"
                    />
                    {errors.emergencyContacts?.[index]?.name && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.emergencyContacts[index]?.name?.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor={`emergencyContacts.${index}.relationship`}>Relationship *</Label>
                    <Input
                      {...register(`emergencyContacts.${index}.relationship` as const)}
                      placeholder="Relationship"
                    />
                    {errors.emergencyContacts?.[index]?.relationship && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.emergencyContacts[index]?.relationship?.message}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`emergencyContacts.${index}.phone`}>Phone *</Label>
                    <Input
                      {...register(`emergencyContacts.${index}.phone` as const)}
                      placeholder="Phone number"
                    />
                    {errors.emergencyContacts?.[index]?.phone && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.emergencyContacts[index]?.phone?.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor={`emergencyContacts.${index}.email`}>Email</Label>
                    <Input
                      type="email"
                      {...register(`emergencyContacts.${index}.email` as const)}
                      placeholder="Email address"
                    />
                    {errors.emergencyContacts?.[index]?.email && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.emergencyContacts[index]?.email?.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {errors.emergencyContacts && !Array.isArray(errors.emergencyContacts) && (
              <p className="text-red-500 text-sm mt-1">{errors.emergencyContacts.message}</p>
            )}

            <Button
              type="button"
              variant="outline"
              onClick={() => appendEmergencyContact({ name: "", relationship: "", phone: "", email: "" })}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Emergency Contact
            </Button>
          </CardContent>
        </Card>

        {/* Terms and Conditions */}
        <Card>
          <CardHeader>
            <CardTitle>Terms & Conditions</CardTitle>
            <CardDescription>Please accept our terms and conditions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="termsAccepted"
                checked={watch("termsAccepted")}
                onCheckedChange={(checked) => handleCheckboxChange("termsAccepted", checked === true)}
              />
              <Label htmlFor="termsAccepted" className="cursor-pointer">
                I accept the terms and conditions *
              </Label>
            </div>
            {errors.termsAccepted && (
              <p className="text-red-500 text-sm mt-1">{errors.termsAccepted.message}</p>
            )}

            <div className="flex items-center space-x-2">
              <Checkbox
                id="privacyAccepted"
                checked={watch("privacyAccepted")}
                onCheckedChange={(checked) => handleCheckboxChange("privacyAccepted", checked === true)}
              />
              <Label htmlFor="privacyAccepted" className="cursor-pointer">
                I accept the privacy policy *
              </Label>
            </div>
            {errors.privacyAccepted && (
              <p className="text-red-500 text-sm mt-1">{errors.privacyAccepted.message}</p>
            )}
          </CardContent>
        </Card>

        {/* Attachments */}
<Card>
  <CardHeader>
    <CardTitle>Attachments</CardTitle>
    <CardDescription>Upload supporting documents</CardDescription>
  </CardHeader>
  <CardContent>
    <FileUploadField control={control} name="attachments" />
    {errors.attachments && (
      <p className="text-red-500 text-sm mt-1">
        {errors.attachments.message as string}
      </p>
    )}
  </CardContent>
</Card>


        {/* Form Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                Form status: {isValid ? "✅ Valid" : "❌ Invalid"} |{" "}
                {isSubmitting ? "⏳ Submitting..." : "📝 Ready to submit"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Button 
          type="submit" 
          className="w-full"
          disabled={isSubmitting || !isValid}
          size="lg"
        >
          {isSubmitting ? "Submitting..." : "Submit Form"}
        </Button>
      </form>
    </div>
  );
}