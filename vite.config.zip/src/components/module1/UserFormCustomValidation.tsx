import React, { useState } from "react";

type Relative = {
  name: string;
  age: string;
  income: string;
  incomeProof: File | null;
};

type FormValues = {
  username: string;
  email: string;
  password: string;
  qualification: string[];
  relatives: Relative[];
};

type RelativeError = {
  name?: string;
  age?: string;
  income?: string;
  incomeProof?: string;
};

type FormErrors = {
  username?: string;
  email?: string;
  password?: string;
  qualification?: string;
  relatives?: RelativeError[];
};

type Touched = {
  username?: boolean;
  email?: boolean;
  password?: boolean;
  qualification?: boolean;
  relatives?: {
    name?: boolean;
    age?: boolean;
    income?: boolean;
    incomeProof?: boolean;
  }[];
};

const qualificationsList = ["B.Tech", "M.Tech", "B.Sc", "M.Sc", "PhD"];

export default function UserFormCustomValidation() {
  const [values, setValues] = useState<FormValues>({
    username: "",
    email: "",
    password: "",
    qualification: [],
    relatives: [],
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Touched>({});

  // ---------------- VALIDATION ----------------
  const validateField = (name: keyof FormValues, value: any) => {
    switch (name) {
      case "username":
        if (!value.trim()) return "Username required";
        if (value.length < 3) return "Min 3 chars";
        return "";

      case "email":
        if (!value) return "Email required";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
          return "Invalid email";
        return "";

      case "password":
        if (!value) return "Password required";
        if (value.length < 6) return "Min 6 chars";
        return "";

      case "qualification":
        if (value.length === 0)
          return "Select at least one qualification";
        return "";
    }
  };

  const validateRelative = (rel: Relative): RelativeError => ({
    name: !rel.name ? "Name required" : "",
    age: !rel.age || +rel.age <= 0 ? "Valid age required" : "",
    income: !rel.income ? "Income required" : "",
    incomeProof: !rel.incomeProof ? "Upload proof" : "",
  });

  // ---------------- MAIN HANDLERS ----------------
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const key = name as keyof FormValues;

    setValues((p) => ({ ...p, [key]: value }));

    if (touched[key]) {
      setErrors((p) => ({
        ...p,
        [key]: validateField(key, value),
      }));
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const key = name as keyof FormValues;

    setTouched((p) => ({ ...p, [key]: true }));
    setErrors((p) => ({
      ...p,
      [key]: validateField(key, value),
    }));
  };

  const handleQualificationChange = (qual: string) => {
    const updated = values.qualification.includes(qual)
      ? values.qualification.filter((q) => q !== qual)
      : [...values.qualification, qual];

    setValues((p) => ({ ...p, qualification: updated }));
    setTouched((p) => ({ ...p, qualification: true }));
    setErrors((p) => ({
      ...p,
      qualification: validateField("qualification", updated),
    }));
  };

  // ---------------- RELATIVE HANDLERS ----------------
  const addRelative = () => {
    setValues((p) => ({
      ...p,
      relatives: [
        ...p.relatives,
        { name: "", age: "", income: "", incomeProof: null },
      ],
    }));
  };

  const removeRelative = (index: number) => {
    setValues((p) => ({
      ...p,
      relatives: p.relatives.filter((_, i) => i !== index),
    }));
  };

  const updateRelative = (
    index: number,
    field: keyof Relative,
    value: any
  ) => {
    const updated = [...values.relatives];
    updated[index] = { ...updated[index], [field]: value };
    setValues((p) => ({ ...p, relatives: updated }));

    const relErrors = updated.map(validateRelative);
    setErrors((p) => ({ ...p, relatives: relErrors }));
  };

  // ---------------- SUBMIT ----------------
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const mainErrors = {
      username: validateField("username", values.username),
      email: validateField("email", values.email),
      password: validateField("password", values.password),
      qualification: validateField(
        "qualification",
        values.qualification
      ),
    };

    const relErrors = values.relatives.map(validateRelative);

    setErrors({ ...mainErrors, relatives: relErrors });

    const hasMainErrors = Object.values(mainErrors).some(Boolean);
    const hasRelErrors = relErrors.some((r) =>
      Object.values(r).some(Boolean)
    );

    if (!hasMainErrors && !hasRelErrors) {
      console.log("FORM DATA:", values);
      alert("Form submitted successfully!");
    }
  };

  // ---------------- UI ----------------
  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 600 }}>
      <h2>User Form</h2>

      <input
        name="username"
        placeholder="Username"
        value={values.username}
        onChange={handleChange}
        onBlur={handleBlur}
      />
      {errors.username && <p>{errors.username}</p>}

      <input
        name="email"
        placeholder="Email"
        value={values.email}
        onChange={handleChange}
        onBlur={handleBlur}
      />
      {errors.email && <p>{errors.email}</p>}

      <input
        type="password"
        name="password"
        placeholder="Password"
        value={values.password}
        onChange={handleChange}
        onBlur={handleBlur}
      />
      {errors.password && <p>{errors.password}</p>}

      <h3>Qualification</h3>
      {qualificationsList.map((q) => (
        <label key={q}>
          <input
            type="checkbox"
            checked={values.qualification.includes(q)}
            onChange={() => handleQualificationChange(q)}
          />
          {q}
        </label>
      ))}
      {errors.qualification && <p>{errors.qualification}</p>}

      <hr />
      <h3>Relatives</h3>
      <button type="button" onClick={addRelative}>
        + Add Relative
      </button>

      {values.relatives.map((rel, i) => (
        <div key={i} style={{ border: "1px solid #ccc", padding: 10 }}>
          <input
            placeholder="Name"
            value={rel.name}
            onChange={(e) =>
              updateRelative(i, "name", e.target.value)
            }
          />
          <input
            placeholder="Age"
            type="number"
            value={rel.age}
            onChange={(e) =>
              updateRelative(i, "age", e.target.value)
            }
          />
          <input
            placeholder="Income"
            type="number"
            value={rel.income}
            onChange={(e) =>
              updateRelative(i, "income", e.target.value)
            }
          />
          <input
            type="file"
            onChange={(e) =>
              updateRelative(
                i,
                "incomeProof",
                e.target.files?.[0] || null
              )
            }
          />

          <button type="button" onClick={() => removeRelative(i)}>
            Remove
          </button>

          {errors.relatives?.[i] &&
            Object.values(errors.relatives[i]).map(
              (err, idx) =>
                err && (
                  <p key={idx} style={{ color: "red" }}>
                    {err}
                  </p>
                )
            )}
        </div>
      ))}

      <button type="submit">Submit</button>
    </form>
  );
}