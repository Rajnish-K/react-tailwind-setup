import React, { useState } from "react";
import { CustomDatePickerWithRange } from "../common_components/CustomDatePickerWithRange";
import { CustomDatePicker } from "../common_components/CustomDatePicker";
import { CustomModal } from "../common_components/CustomModal";
import { Button } from "../ui/button";

export default function FormWithDatePickers() {

  const [isOpen, setIsOpen] = useState(false);
   const holidays = [new Date(2025, 0, 26), new Date(2025, 7, 15)];
  const disabledDates = [new Date(2025, 1, 14)];
  const descriptions = {
    "15-08-2025": "Independence Day 🎉",
    "26-01-2025": "Republic Day 🇮🇳",
  };

  return (
    <>

<div className="p-10">
       <CustomDatePicker
        selectedDate="15-08-2025"
        holidays={holidays}
        disabledDates={disabledDates}
        dateDescriptions={descriptions}
        onSelect={(d) => console.log("Selected date:", d)}
        colors={{
          selected: "bg-green-200",
          weekend: "bg-pink-100",
          holiday: "bg-yellow-200",
        }}
      />
    </div>

    <div className="p-10">
      <h2 className="text-xl mb-4">Date Range Picker</h2>
      <CustomDatePickerWithRange
        holidays={[new Date(2025, 0, 26), new Date(2025, 7, 15)]} // Republic & Independence Day
        disabledDates={[new Date(2025, 1, 14)]}
        colors={{
          range: "bg-green-200",
          weekend: "bg-pink-100",
          holiday: "bg-yellow-200",
        }}
        onSelect={(range) => {
          console.log("Selected range:", range);
        }}
      />
    </div>

     <div className="p-10">
      <h2 className="text-xl mb-4">Single Date Picker</h2>
       <CustomDatePicker
        selectedDate="15-08-2025"
        holidays={[new Date(2025, 0, 26), new Date(2025, 7, 15)]}
        disabledDates={[new Date(2025, 1, 14)]}
        dateDescriptions={{
          "15-08-2025": "Independence Day 🎉",
          "26-01-2025": "Republic Day 🇮🇳",
          "14-02-2025": "Valentine's Day ❤️"
        }}
        onSelect={(date) => console.log("Selected date:", date)}
        colors={{
          selected: "bg-green-200",
          weekend: "bg-pink-100",
          holiday: "bg-yellow-200",
        }}
      />
    </div>

     <Button onClick={() => setIsOpen(true)}>Open Modal</Button>

      <CustomModal
        open={isOpen}
        onOpenChange={setIsOpen}
        title="My Custom Modal"
        description="You can pass any HTML or JSX here"
      >
        <div className="space-y-3">
          <p className="text-gray-700">
            This is an example of <strong>HTML content</strong> passed via
            <code>children</code>.
          </p>
          <ul className="list-disc list-inside text-sm text-gray-600">
            <li>Supports Tailwind styling</li>
            <li>Can be dynamic JSX</li>
            <li>Fully reusable</li>
          </ul>
          <Button onClick={() => setIsOpen(false)}>Close</Button>
        </div>
      </CustomModal>

      <div className="grid grid-flow-col justify-items-center ...">
  <div className="p-4 bg-green-100 m-2">01</div>
  <div className="p-4 bg-green-100 m-2">02</div>
  <div className="p-4 bg-green-100 m-2">03</div>
</div>
    
    </>
  );
}
