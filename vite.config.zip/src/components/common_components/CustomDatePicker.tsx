import React, { useState, useEffect } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { formatDate, parseDate } from "../../utils/date";
import {
  addMonths,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isWeekend,
  isSameDay,
  setMonth,
  setYear,
} from "date-fns";

interface CustomDatePickerProps {
  selectedDate?: string | null; // API format "dd-MM-yyyy"
  onSelect?: (date: Date) => void;
  holidays?: Date[];
  disabledDates?: Date[];
  dateDescriptions?: Record<string, string>; // dd-MM-yyyy -> description
  colors?: {
    selected?: string;
    weekend?: string;
    holiday?: string;
  };
}

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  selectedDate = null,
  onSelect,
  holidays = [],
  disabledDates = [],
  dateDescriptions = {},
  colors = {
    selected: "bg-blue-200",
    weekend: "bg-red-100",
    holiday: "bg-yellow-200",
  },
}) => {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState<Date | null>(null);
  const [month, setMonthState] = useState(new Date());

  useEffect(() => {
    if (selectedDate) {
      const parsed = parseDate(selectedDate);
      setDate(parsed);
      setMonthState(parsed);
    }
  }, [selectedDate]);

  const days = eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month),
  });

  const handleDayClick = (day: Date) => {
    if (isDisabled(day)) return;
    setDate(day);
    onSelect?.(day);
    setOpen(false);
  };

  const isDisabled = (day: Date) =>
    disabledDates.some((d) => isSameDay(d, day));

  const getDayClass = (day: Date) => {
    const isHoliday = holidays.some((h) => isSameDay(h, day));
    const isWeekEnd = isWeekend(day);
    const isSelected = date && isSameDay(day, date);

    return cn(
      "w-10 h-10 flex items-center justify-center rounded cursor-pointer",
      isSelected && colors.selected,
      isHoliday && colors.holiday,
      isWeekEnd && colors.weekend,
      isDisabled(day) && "opacity-50 cursor-not-allowed"
    );
  };

  const handleMonthChange = (increment: number) => {
    setMonthState(addMonths(month, increment));
  };

  const handleMonthSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setMonthState(setMonth(month, parseInt(e.target.value)));
  };

  const handleYearSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setMonthState(setYear(month, parseInt(e.target.value)));
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  const years = Array.from({ length: 30 }, (_, i) => 2010 + i);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className="border p-2 rounded w-40 text-left">
          {date ? formatDate(date) : "Select date"}
        </button>
      </PopoverTrigger>
      <PopoverContent className="p-4">
        {/* Month-Year Selector */}
        <div className="flex justify-between items-center mb-2">
          <button onClick={() => handleMonthChange(-1)} className="px-2">‹</button>
          <div className="flex gap-2">
            <select
              value={month.getMonth()}
              onChange={handleMonthSelect}
              className="border rounded px-2"
            >
              {monthNames.map((m, idx) => (
                <option key={m} value={idx}>{m}</option>
              ))}
            </select>
            <select
              value={month.getFullYear()}
              onChange={handleYearSelect}
              className="border rounded px-2"
            >
              {years.map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
          <button onClick={() => handleMonthChange(1)} className="px-2">›</button>
        </div>

        {/* Days grid with tooltips */}
        <TooltipProvider>
          <div className="grid grid-cols-7 gap-1">
            {days.map((day) => {
              const key = formatDate(day);
              const description = dateDescriptions[key];
              return (
                <Tooltip key={day.toString()}>
                  <TooltipTrigger asChild>
                    <div
                      onClick={() => handleDayClick(day)}
                      className={getDayClass(day)}
                    >
                      {day.getDate()}
                    </div>
                  </TooltipTrigger>
                  {description && (
                    <TooltipContent>{description}</TooltipContent>
                  )}
                </Tooltip>
              );
            })}
          </div>
        </TooltipProvider>
      </PopoverContent>
    </Popover>
  );
};
