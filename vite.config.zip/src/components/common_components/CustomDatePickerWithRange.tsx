import React, { useState } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { formatDate } from "../../utils/date";
import {
  addMonths,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isWeekend,
  isSameDay,
  isWithinInterval,
  setMonth,
  setYear,
} from "date-fns";

interface CustomDatePickerProps {
  selectedRange?: { start: Date | null; end: Date | null };
  onSelect?: (range: { start: Date | null; end: Date | null }) => void;
  holidays?: Date[];
  disabledDates?: Date[];
  colors?: {
    range?: string;
    weekend?: string;
    holiday?: string;
  };
}

export const CustomDatePickerWithRange: React.FC<CustomDatePickerProps> = ({
  selectedRange,
  onSelect,
  holidays = [],
  disabledDates = [],
  colors = {
    range: "bg-blue-200",
    weekend: "bg-red-100",
    holiday: "bg-yellow-200",
  },
}) => {
  const [range, setRange] = useState<{ start: Date | null; end: Date | null }>(
    selectedRange || { start: null, end: null }
  );
  const [month, setMonthState] = useState(new Date());

  const days = eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month),
  });

  const handleDayClick = (day: Date) => {
    if (isDisabled(day)) return;

    if (!range.start || (range.start && range.end)) {
      setRange({ start: day, end: null });
    } else {
      const startDate = range.start;
      const endDate = day < startDate ? startDate : day;
      setRange({ start: startDate, end: endDate });
      onSelect?.({ start: startDate, end: endDate });
    }
  };

  const isDisabled = (day: Date) => {
    return disabledDates.some((d) => isSameDay(d, day));
  };

  const getDayClass = (day: Date) => {
    const isInRange =
      range.start &&
      range.end &&
      isWithinInterval(day, { start: range.start, end: range.end });

    const isHoliday = holidays.some((h) => isSameDay(h, day));
    const isWeekEnd = isWeekend(day);

    return cn(
      "w-10 h-10 flex items-center justify-center rounded cursor-pointer",
      isInRange && colors.range,
      isHoliday && colors.holiday,
      isWeekEnd && colors.weekend,
      isDisabled(day) && "opacity-50 cursor-not-allowed"
    );
  };

  const handleMonthChange = (increment: number) => {
    setMonthState(addMonths(month, increment));
  };

  const handleMonthSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setMonthState(setMonth(month, parseInt(e.target.value)));
  };

  const handleYearSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setMonthState(setYear(month, parseInt(e.target.value)));
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  const years = Array.from({ length: 30 }, (_, i) => 2010 + i);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="border p-2 rounded w-48 text-left">
          {range.start ? formatDate(range.start) : "Select date"}{" "}
          {range.end ? ` - ${formatDate(range.end)}` : ""}
        </button>
      </PopoverTrigger>
      <PopoverContent className="p-4">
        {/* Month-Year Selector */}
        <div className="flex justify-between items-center mb-2">
          <button onClick={() => handleMonthChange(-1)} className="px-2">‹</button>
          <div className="flex gap-2">
            <select
              value={month.getMonth()}
              onChange={handleMonthSelect}
              className="border rounded px-2"
            >
              {monthNames.map((m, idx) => (
                <option key={m} value={idx}>{m}</option>
              ))}
            </select>
            <select
              value={month.getFullYear()}
              onChange={handleYearSelect}
              className="border rounded px-2"
            >
              {years.map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>
          <button onClick={() => handleMonthChange(1)} className="px-2">›</button>
        </div>

        {/* Days grid */}
        <div className="grid grid-cols-7 gap-1">
          {days.map((day) => (
            <div
              key={day.toString()}
              onClick={() => handleDayClick(day)}
              className={getDayClass(day)}
            >
              {day.getDate()}
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};
