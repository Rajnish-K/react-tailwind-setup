import { useFieldArray } from "react-hook-form";
import type { Control } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Trash2, Upload } from "lucide-react";

type Props = {
  control: Control<any>;
  name: string; // e.g. "attachments"
};

export function FileUploadField({ control, name }: Props) {
  const { fields, append, remove } = useFieldArray({
    control,
    name,
  });

  const handleFiles = (files: FileList | null) => {
    if (!files) return;

    Array.from(files).forEach((file) => {
      append({
        file,
        name: file.name,
        size: file.size,
        type: file.type,
      });
    });
  };

  return (
    <div className="space-y-4">
      <label className="block font-medium">Attachments *</label>

      <div className="border-2 border-dashed p-6 rounded-lg text-center">
        <input
          type="file"
          multiple
          className="hidden"
          id="fileUpload"
          onChange={(e) => handleFiles(e.target.files)}
        />
        <label htmlFor="fileUpload" className="cursor-pointer">
          <Upload className="mx-auto h-8 w-8 mb-2" />
          Click to upload files
        </label>
      </div>

      {fields.map((field, index) => (
        <div
          key={field.id}
          className="flex justify-between items-center border p-3 rounded"
        >
          <div>
            <p className="text-sm font-medium">{field.name}</p>
            <p className="text-xs text-gray-500">
              {(field.size / 1024).toFixed(2)} KB
            </p>
          </div>

          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => remove(index)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  );
}
