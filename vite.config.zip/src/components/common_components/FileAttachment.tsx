// components/FileAttachment.tsx
import { useRef, useState } from "react";
// import { Button } from "@/components/ui/button";

import { Trash2, Eye, Upload } from "lucide-react";
// import { ApiFile, AttachmentItem } from "@/types/file";
import { v4 as uuid } from "uuid";
import type { ApiFile, AttachmentItem } from "../../types/file";
import { Button } from "../ui/button";

interface FileAttachmentProps {
  initialFiles?: ApiFile[];

  enableView?: boolean;
  enableDelete?: boolean;
  enableUpload?: boolean;

  onChange?: (files: {
    added: File[];
    removed: number[];
  }) => void;
}


const FileAttachment = ({
  initialFiles = [],
  enableView = true,
  enableDelete = true,
  enableUpload = true,
  onChange,
}: FileAttachmentProps) => {
  const inputRef = useRef<HTMLInputElement>(null);

  console.log("Initial Files:", initialFiles);

  

  const [attachments, setAttachments] = useState<AttachmentItem[]>([
    ...initialFiles.map((file) => ({
      type: "api" as const,
      data: file,
    })),
  ]);

  const [removedApiFileIds, setRemovedApiFileIds] = useState<number[]>([]);

  // 🔹 Upload local files
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newFiles: AttachmentItem[] = Array.from(files).map((file) => ({
      type: "local",
      data: {
        tempId: uuid(),
        file,
      },
    }));

    const updated = [...attachments, ...newFiles];
    setAttachments(updated);
    emitChange(updated);
  };

  // 🔹 Delete file
  const handleDelete = (item: AttachmentItem) => {
  const updated = attachments.filter((f) => f !== item);

  let updatedRemovedIds = removedApiFileIds;

  if (item.type === "api") {
    updatedRemovedIds = [...removedApiFileIds, item.data.fileId];
    setRemovedApiFileIds(updatedRemovedIds);
  }

  setAttachments(updated);
  emitChange(updated, updatedRemovedIds);
};


  // 🔹 View file
  const handleView = (item: AttachmentItem) => {
    if (item.type === "api") {
      if (item.data.fileUrl) {
        window.open(item.data.fileUrl, "_blank");
      }
    } else {
      const url = URL.createObjectURL(item.data.file);
      window.open(url, "_blank");
    }
  };

  const emitChange = (
  updated: AttachmentItem[],
  removedIds = removedApiFileIds
) => {
  if (!onChange) return;

  onChange({
    added: updated
      .filter((i) => i.type === "local")
      .map((i) => i.data.file),
    removed: removedIds,
  });
};


  return (
    <div className="space-y-3">
      {/* Upload Button */}
      {enableUpload && (
        <>
          <input
            ref={inputRef}
            type="file"
            hidden
            multiple
            onChange={handleUpload}
          />

          <Button
            type="button"
            variant="outline"
            onClick={() => inputRef.current?.click()}
            className="flex items-center gap-2"
          >
            <Upload size={16} />
            Upload File
          </Button>
        </>
      )}

      {/* File List */}
      <div className="space-y-2">
        {attachments.map((item, index) => (
          <div
            key={index}
            className="flex items-center justify-between rounded-md border p-2"
          >
            <span className="text-sm truncate max-w-[220px]">
              {item.type === "api"
                ? item.data.fileName
                : item.data.file.name}
            </span>

            <div className="flex gap-1">
              {enableView && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => handleView(item)}
                >
                  <Eye size={16} />
                </Button>
              )}

              {enableDelete && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => handleDelete(item)}
                >
                  <Trash2 size={16} />
                </Button>
              )}
            </div>
          </div>
        ))}

        {attachments.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No files attached
          </p>
        )}
      </div>
    </div>
  );
};

export default FileAttachment;
