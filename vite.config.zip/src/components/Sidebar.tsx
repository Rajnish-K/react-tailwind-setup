import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { routerConfig } from "./../routes/router";

type RouteItem = any;

const SidebarItem = ({
  route,
  parentPath = "",
  subItem=false
}: {
  route: RouteItem;
  parentPath?: string;
  subItem?: boolean;
}) => {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  if (!route.showInMenu) return null;

  const fullPath = route.index
    ? parentPath
    : `${parentPath}/${route.path}`.replace("//", "/");

  const isActive = location.pathname.startsWith(fullPath);

  console.log("Rendering SidebarItem:", {
    route,
    fullPath,
    isActive,
    locationPath: location.pathname,
  }); 

  return (
    <li>
      <div
        style={{
          padding: "8px",
          cursor: "pointer",
          fontWeight: isActive ? "bold" : "normal",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
        }}
        onClick={() => route.children && setOpen(!open)}
      >
        {route.element && route.path ? (
         <>
         {isActive ? <span>{route.label}</span> : <Link to={fullPath}>{route.label}</Link>}
         </> 
        ) : (
          <>
          <span>{route.label}</span>
          {subItem ? (<span>{open ? " ▼" : " ▶" }</span>) : (<span>{open ? "-" : " +"   }</span>)}

          </>
        )}
      </div>

      {route.children && open && (
        <ul style={{ paddingLeft: "16px" }}>
          {route.children.map((child: RouteItem) => (
            <SidebarItem
              key={child.path || "index"}
              subItem={true}
              route={child}
              parentPath={fullPath}
            />
          ))}
        </ul>
      )}
    </li>
  );
};

export const Sidebar = () => {
  const protectedRoutes =
    routerConfig.find((r) => r.path === "/app")?.children || [];

  return (
    <aside style={{ width: "250px" }}>
      <ul>
        {protectedRoutes.map((route: RouteItem) => (
          <SidebarItem key={route.path} route={route} parentPath="/app" subItem={false} />
        ))}
      </ul>
    </aside>
  );
};
