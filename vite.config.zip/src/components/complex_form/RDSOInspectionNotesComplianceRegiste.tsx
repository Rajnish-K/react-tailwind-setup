import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';

import {
  Form,
} from '@/components/ui/form';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, Trash2, Upload, Plus } from 'lucide-react';

const fileSchema = z.object({
  name: z.string(),
  file: z.any(),
});

const formSchema = z.object({
  notes: z.array(fileSchema).optional(),
});

type FormValues = z.infer<typeof formSchema>;

type Section = {
  id: number;
  values: FormValues;
};


var abc:string = "abc";
let abcd:string = "abcd";
const RDSOInspectionNotesComplianceRegiste: React.FC = () => {
  console.log("abc", abc, abcd)
  
  const [sections, setSections] = useState<Section[]>([
    { id: 1, values: { notes: [] } },
  ]);
  const [selectedId, setSelectedId] = useState<number>(1);
  const [nextId, setNextId] = useState<number>(2);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { notes: [] },
  });

  // Reset form when selectedId changes (NOT when sections change) — prevents loop
  useEffect(() => {
    const sel = sections.find((s) => s.id === selectedId) ?? sections[0];
    if (sel) form.reset(sel.values);
  }, [selectedId, form]); // <-- removed `sections` from deps to avoid loop

  // Subscribe to form changes and sync into the selected section.
  useEffect(() => {
    const subscription = form.watch((values) => {
      setSections((prev:any) => {
        const idx = prev.findIndex((s:any) => s?.id === selectedId);
        if (idx === -1) return prev;

        const currentNotes = prev[idx].values?.notes ?? [];
        const newNotes = values?.notes ?? [];

        // simple shallow check: same length and same names => skip update
        const same =
          currentNotes.length === newNotes.length &&
          currentNotes.every((cn:any, i:number) => cn?.name === newNotes[i]?.name);

        if (same) return prev;

        // otherwise produce updated array
        return prev.map((s:any) =>
          s.id === selectedId ? { ...s, values: values ?? { notes: [] } } : s
        );
      });
    });
    return () => subscription.unsubscribe();
  }, [form, selectedId]);

  const selectedIndex = sections.findIndex((s) => s.id === selectedId);
  const selectedSection = sections[selectedIndex] ?? sections[0];
  const displayName = (index: number) => `Notes ${index + 1}`;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const uploaded = Array.from(files).map((file) => ({
      name: file.name,
      file,
    }));

    setSections((prev) =>
      prev.map((s) =>
        s.id === selectedId
          ? { ...s, values: { notes: [...(s.values.notes || []), ...uploaded] } }
          : s
      )
    );

    const updated = [...(selectedSection?.values?.notes || []), ...uploaded];
    form.setValue('notes', updated);
  };

  console.log(selectedSection?.values?.notes, "sections=", sections);

  const handleDeleteFile = (index: number) => {
    console.log("updated===");
    setSections((prev) =>
      prev.map((s) =>
        s.id === selectedId
          ? { ...s, values: { notes: (s.values.notes ?? []).filter((_, i) => i !== index) } }
          : s
      )
    );
    const updated = (selectedSection?.values?.notes ?? []).filter((_, i) => i !== index);
    console.log("updated===", updated);
    form.setValue('notes', updated);
  };

  const handleAddSection = () => {
    const newSection: Section = { id: nextId, values: { notes: [] } };
    setNextId((n) => n + 1);
    setSections((prev) => [...prev, newSection]);
    setSelectedId(newSection.id);
    // selectedId change will trigger the reset useEffect
  };

  const handleClear = () => {
    setSections((prev) => prev.map((s) => (s.id === selectedId ? { ...s, values: { notes: [] } } : s)));
    form.reset({ notes: [] });
  };

  const handleDeleteForm = () => {
    const idx = sections.findIndex((s) => s.id === selectedId);
    if (idx === -1) return;

    const newSections = sections.filter((s) => s.id !== selectedId);

    if (newSections.length === 0) {
      const defaultSection: Section = { id: nextId, values: { notes: [] } };
      setNextId((n) => n + 1);
      setSections([defaultSection]);
      setSelectedId(defaultSection.id);
      form.reset(defaultSection.values);
      return;
    }

    // pick previous section if possible, else next one
    const chooseIndex = Math.max(0, idx - 1);
    const newSelected = newSections[Math.min(chooseIndex, newSections.length - 1)];

    setSections(newSections);
    setSelectedId(newSelected.id);
    form.reset(newSelected.values);
  };

  const onSubmit = (values: FormValues) => {
    console.log('Submitted:', {
      sectionIndex: sections.findIndex((s) => s.id === selectedId),
      sectionId: selectedId,
      values,
    });
  };

  return (
    <div className="flex-1 p-6">
      <div className=" border-b pb-4">
        <h2 className="text-xl font-semibold">RDSO Inspection notes & compliance Register</h2>
      </div>

      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-48 border-r space-y-2 pt-2 pr-6">
          {sections.map((section, i) => (
            <Button
              key={section.id}
              variant={selectedId === section.id ? 'secondary' : 'ghost'}
              className="w-full justify-start text-left h-auto py-2"
              onClick={() => setSelectedId(section.id)}
            >
              {displayName(i)}
            </Button>
          ))}
          <Button
            variant="ghost"
            onClick={handleAddSection}
            className="w-full justify-start text-primary hover:bg-primary/10 h-auto py-2"
          >
            + Add Notes
          </Button>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between pt-6">
                <Badge variant="outline">
                  {selectedIndex >= 0 ? displayName(selectedIndex) : 'Notes'}
                </Badge>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleClear} type="button">
                    Clear All Fields
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeleteForm}
                    className="text-destructive"
                    type="button"
                  >
                    Delete Form
                  </Button>
                </div>
              </div>

              {/* Upload Box */}
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <input
                  type="file"
                  multiple
                  className="hidden"
                  id="file-upload"
                  onChange={handleFileChange}
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer flex flex-col items-center text-gray-500"
                >
                  <Upload className="w-8 h-8 mb-2" />
                  Drag & Drop files here or <span className="text-blue-600">Choose a file</span>
                </label>
              </div>

              {/* Uploaded files list */}
              <div className="space-y-2">
                {(selectedSection?.values?.notes ?? []).map((note, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between border rounded-md p-2"
                  >
                    <span>{note.name}</span>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(URL.createObjectURL(note.file))}
                      >
                        <Eye className="w-4 h-4 mr-1" /> View
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="text-destructive"
                        onClick={() => handleDeleteFile(index)}
                      >
                        <Trash2 className="w-4 h-4 mr-1" /> Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="flex justify-between mt-8">
                <Button type="button" variant="outline" className="rounded-4xl">
                  Back
                </Button>
                <div className="flex gap-3">
                  <Button type="button" className="rounded-4xl" variant="outline">
                    Save as Draft
                  </Button>
                  <Button type="button"className="rounded-4xl" variant="outline">
                    Cancel
                  </Button>
                  <Button type="submit" className="rounded-4xl bg-[#104685] ">Submit</Button>
                </div>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default RDSOInspectionNotesComplianceRegiste;
