import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';

import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, Trash2, Plus, ChevronRight, ChevronDown } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

const statementSchema = z.object({
  girderComponentId: z.string().min(1, "Required"),
  typeAndSize: z.string().min(1, "Required"),
  materialTestCertNo: z.string().min(1, "Required"),
  castNo: z.string().min(1, "Required"),
  steelQty: z.string().min(1, "Required"),
});

const formSchema = z.object({
  nameOfWork: z.string().min(1, "Required"),
  contractNo: z.string().optional(),
  spanNo: z.string().min(1, "Required"),
  statements: z.array(statementSchema),
});

type FormValues = z.infer<typeof formSchema>;

const defaultStatement: FormValues['statements'][number] = {
  girderComponentId: '',
  typeAndSize: '',
  materialTestCertNo: '',
  castNo: '',
  steelQty: '',
};

type Section = {
  id: number;
  values: FormValues;
};

const ensureFormValues = (v?: Partial<FormValues>): FormValues => ({
  nameOfWork: v?.nameOfWork ?? '',
  contractNo: v?.contractNo ?? '',
  spanNo: v?.spanNo ?? '',
  statements:
    v?.statements && v.statements.length > 0
      ? v.statements.map(s => ({
        girderComponentId: s?.girderComponentId ?? '',
        typeAndSize: s?.typeAndSize ?? '',
        materialTestCertNo: s?.materialTestCertNo ?? '',
        castNo: s?.castNo ?? '',
        steelQty: s?.steelQty ?? '',
      }))
      : [defaultStatement],
});

const MaterialOfferingInspectionRegister: React.FC = () => {
  const [sections, setSections] = useState<Section[]>([
    { id: 1, values: ensureFormValues() },
  ]);
  const [selectedId, setSelectedId] = useState<number>(1);
  const [nextId, setNextId] = useState<number>(2);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: sections[0].values,
    mode: "onChange",
    reValidateMode: "onChange",
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'statements',
  });

  const selectedIndex = sections.findIndex((s) => s.id === selectedId);
  const selectedSection = sections[selectedIndex] ?? sections[0];
  const displayName = (index: number) => `MOIR ${index + 1}`;

  // Save current section before switching
  const switchSection = (newId: number) => {
    const currentValues = ensureFormValues(form.getValues());
    setSections(prev =>
      prev.map(s =>
        s.id === selectedId ? { ...s, values: currentValues } : s
      )
    );

    setSelectedId(newId);

    const nextValues =
      sections.find((s) => s.id === newId)?.values ?? ensureFormValues();
    form.reset(nextValues);
  };
console.log("nextId===", nextId);
  const handleAddSMTC = () => {
    const currentValues = ensureFormValues(form.getValues());
    setSections(prev =>
      prev.map(s =>
        s.id === selectedId ? { ...s, values: currentValues } : s
      )
    );

    const newSection: Section = {
      id: nextId,
      values: ensureFormValues(),
    };
    setNextId((n) => n + 1);
    setSections((prev) => [...prev, newSection]);
    setSelectedId(newSection.id);
    form.reset(newSection.values);
  };

  const handleClear = () => {
    const clearedValues = ensureFormValues();
    form.reset(clearedValues);
    setSections((prev) =>
      prev.map((s) =>
        s.id === selectedId ? { ...s, values: clearedValues } : s
      )
    );
  };

  const handleDeleteForm = () => {
    // const currentValues = ensureFormValues(form.getValues());

    // console.log("form.getValues()", form.getValues())

    // setSections(prev =>
    //   prev.map(s =>
    //     s.id === selectedId ? { ...s, values: currentValues } : s
    //   )
    // );

    const idx = sections.findIndex((s) => s.id === selectedId);
    if (idx === -1) return;

    const newSections = sections.filter((s) => s.id !== selectedId);

    if (newSections.length === 0) {
      const defaultSection: Section = {
        id: nextId,
        values: ensureFormValues(),
      };
      setNextId((n) => n + 1);
      setSections([defaultSection]);
      setSelectedId(defaultSection.id);
      form.reset(defaultSection.values);
      return;
    }

    const chooseIndex = Math.max(0, idx - 1);
    const newSelected = newSections[Math.min(chooseIndex, newSections.length - 1)];

    setSections(newSections);
    setSelectedId(newSelected.id);
    form.reset(newSelected.values);
  };

  const handleAppendStatement = () => append(defaultStatement);
  const handleRemoveStatement = (index: number) => remove(index);

  const onSubmit = (values: FormValues) => {
    console.log('Submitted:', {
      smtcIndex: sections.findIndex((s) => s.id === selectedId),
      smtcId: selectedId,
      values,
    });
  };

  return (
    <div className="flex-1 p-6">
      <div className=" border-b pb-4">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-semibold">Material offering and inspection register</h2>
        </div>
      </div>
      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-48 border-r space-y-2 pt-2 pr-6">
          {sections.map((s, i) => (
            <Button
              key={s.id}
              variant={selectedId === s.id ? 'secondary' : 'ghost'}
              className="w-full justify-start text-left h-auto py-2"
              onClick={() => switchSection(s.id)}
            >
              {displayName(i)}
            </Button>
          ))}
          <Button
            variant="ghost"
            onClick={handleAddSMTC}
            className="w-full justify-start text-primary hover:bg-primary/10 h-auto py-2"
          >
            + Add MOIR
          </Button>
        </div>

        {/* Main Form */}
        <div className="flex-1">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="flex items-center justify-between border-bottom pt-6">
                <Badge variant="outline">{selectedIndex >= 0 ? displayName(selectedIndex) : 'MOIR'}</Badge>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleClear} type="button">
                    <Eye className="w-4 h-4 mr-1" /> Clear All Fields
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeleteForm}
                    className="text-destructive"
                    type="button"
                  >
                    <Trash2 className="w-4 h-4 mr-1" /> Delete Form
                  </Button>
                </div>
              </div>

              {/* General Fields */}
              <FormField
                control={form.control}
                name="nameOfWork"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center gap-6">
                    <div className="w-64">
                      <FormLabel>Description of component/fitting</FormLabel>
                    </div>
                    <div className="flex-1">
                      <FormControl><Input {...field} /></FormControl>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contractNo"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center gap-6">
                    <div className="w-64">
                      <FormLabel>Quantity required per span:</FormLabel>
                    </div>
                    <div className="flex-1">
                      <FormControl><Input {...field} /></FormControl>
                    </div>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="spanNo"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center gap-6">
                    <div className="w-64">
                      <FormLabel>Span No.</FormLabel>
                    </div>
                    <div className="flex-1">
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              {/* Dynamic Statement Sections */}
              {fields.map((field, index) => (
                <div key={field.id} className=" rounded-md space-y-4">
                  {/* <h2 className="text-lg font-semibold mb-4">Span No {index + 1}</h2> */}

                  <Collapsible key={index + 1} className="border rounded-lg mb-4" defaultOpen={index === 0}>

                    <CollapsibleTrigger asChild>
                      <div className="flex justify-between items-center p-3 cursor-pointer bg-gray-50 group">
                        <span>Span No {index + 1}</span>
                        <div className="flex items-center">
                          <ChevronRight className="h-4 w-4 group-data-[state=open]:hidden" />
                          <ChevronDown className="h-4 w-4 hidden group-data-[state=open]:block" />
                        </div>
                      </div>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="grid grid-cols-1 gap-4">
                        <FormField
                          control={form.control}
                          name={`statements.${index}.girderComponentId`}
                          render={({ field }) => (
                            <FormItem className="p-4 flex items-center space-x-4">
                              <FormLabel className="w-64">Initial of Supervisor offering material for inspection</FormLabel>
                              <FormControl><Input {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`statements.${index}.typeAndSize`}
                          render={({ field }) => (
                            <FormItem className="p-4 flex items-center space-x-4">
                              <FormLabel className="w-64">Inspecting officials Remark</FormLabel>
                              <FormControl><Input {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`statements.${index}.materialTestCertNo`}
                          render={({ field }) => (
                            <FormItem className="p-4 flex items-center space-x-4">
                              <FormLabel className="w-64">Compliance action</FormLabel>
                              <FormControl><Input {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`statements.${index}.castNo`}
                          render={({ field }) => (
                            <FormItem className="p-4 flex items-center space-x-4">
                              <FormLabel className="w-64">Seal & initial of Inspecting official</FormLabel>
                              <FormControl><Input {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name={`statements.${index}.steelQty`}
                          render={({ field }) => (
                            <FormItem className="p-4 flex items-center space-x-4">
                              <FormLabel className="w-64">Despatch & consignee details</FormLabel>
                              <FormControl><Input {...field} /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                  <div className="flex justify-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveStatement(index)}
                      type="button"
                    >
                      <Trash2 className="w-4 h-4 mr-1" /> Remove Row
                    </Button>
                  </div>
                </div>
              ))}

              <Button
                type="button"
                variant="ghost"
                onClick={handleAppendStatement}
                className="text-primary"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add New Detail
              </Button>

              {/* Footer */}
              <div className="flex justify-between mt-8">
                <Button type='button' variant="outline" className="rounded-4xl" onClick={() => console.log("back clicked!")}>Back</Button>
                <div className="flex gap-3">
                  <Button type='button' variant="outline" className="rounded-4xl">Save as Draft</Button>
                  <Button type='button' variant="outline" className="rounded-4xl">Cancel</Button>
                  <Button type="submit" className="rounded-4xl bg-[#104685] ">Submit</Button>
                </div>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default MaterialOfferingInspectionRegister;
