import { useNavigate } from "react-router-dom";
import { useTranslation } from 'react-i18next';
import LanguageSelector from "../../common_components/LanguageSelector";

export default function Login() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    localStorage.setItem("token", "demo-token");
    navigate("/app/ess");
  }

  return (
    <>
    <h1>{t('welcome')}</h1>
    <LanguageSelector />
    <form onSubmit={handleLogin} className="p-4 max-w-sm mx-auto">
      <input type="text" placeholder="Username" className="border p-2 w-full mb-2" />
      <input type="password" placeholder="Password" className="border p-2 w-full mb-2" />
      <button className="bg-blue-500 text-white px-4 py-2 w-full">Login</button>
    </form>
    </>
  );
}