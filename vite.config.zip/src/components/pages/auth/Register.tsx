export default function Register() {
  return (
    <form className="p-4 max-w-sm mx-auto">
      <input type="text" placeholder="Username" className="border p-2 w-full mb-2" />
      <input type="email" placeholder="Email" className="border p-2 w-full mb-2" />
      <input type="password" placeholder="Password" className="border p-2 w-full mb-2" />
      <button className="bg-green-500 text-white px-4 py-2 w-full">Register</button>
    </form>
  );
}