export default function ForgotPassword() {
  return (
    <form className="p-4 max-w-sm mx-auto">
      <input type="email" placeholder="Enter your email" className="border p-2 w-full mb-2" />
      <button className="bg-yellow-500 text-white px-4 py-2 w-full">Reset Password</button>
    </form>
  );
}