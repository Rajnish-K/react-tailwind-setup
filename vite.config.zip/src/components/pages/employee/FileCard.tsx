import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, Eye, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileCardProps {
  file: any;
  theme?: "dark" | "light";
  onDelete?: () => void;
  onPreview?: () => void;
  onDownload?: () => void;
  showDelete?: boolean;
  showPreview?: boolean;
  className?: string;
}

export function FileCard({
  file,
  theme = "light",
  onDelete,
  onPreview,
  onDownload,
  showDelete = false,
  showPreview = false,
  className,
}: FileCardProps) {
  const fileName = file?.fileName || file?.name || "";
  const fileSize = file?.fileSize || file?.size || 0;
  const displayName = fileName.split(".")[0];
  const extension = fileName.split(".").pop()?.toUpperCase();

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={cn(
              "p-3 rounded-lg",
              theme === "dark" 
                ? "bg-yellow-500/10 text-yellow-500"
                : "bg-gray-100"
            )}>
              <FileText className="h-6 w-6" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {displayName}
              </p>
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <span>{extension}</span>
                <span>•</span>
                <span>{formatFileSize(fileSize)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
            {onDownload && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDownload}
              >
                <Download className="h-4 w-4" />
              </Button>
            )}
            
            {showPreview && onPreview && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onPreview}
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
            
            {showDelete && onDelete && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                className={theme === "dark" ? "text-yellow-500" : "text-gray-500"}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}