import FileAttachment from "../../common_components/FileAttachment";

export const AttachFileComponent: React.FC = () => {
    const updateState = (addedFiles: File[], removedApiFileIds: number[]) => {
        // Update your component state or perform actions based on file changes
        console.log("Files added:", addedFiles);
        console.log("API File IDs removed:", removedApiFileIds);
    };
    return (
        <div className="max-w-3xl mx-auto mt-10 p-6 bg-white rounded-xl shadow">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Attach File Component</h2>
            {/* File attachment UI would go here */}
            <FileAttachment
                initialFiles={[
                    { fileId: 2, fileName: "att1.pdf", fileUrl: "/files/att1.pdf" },
                    { fileId: 5, fileName: "att2.png", fileUrl: "/files/att2.png" },
                ]}
                onChange={({ added, removed }) => {
                    updateState(added, removed);
                    // console.log("New files:", added);
                    // console.log("Removed API file IDs:", removed);
                }}
            />
        </div>
    );
}