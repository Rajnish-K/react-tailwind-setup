import React, { useState } from "react";
import type { Employee } from "../../../types/Employee";
import EmployeeList from "../../module1/EmployeeList";
import { Outlet, useNavigate, useOutlet } from "react-router-dom";

const EmployeePage: React.FC = () => {
  const navigate = useNavigate();
  const outlet = useOutlet(); // 👈 detect child route

  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: 1,
      name: "Ravi Kumar",
      email: "ravi@example.com",
      role: "Developer",
      department: "IT",
    },
    {
      id: 2,
      name: "Anita Sharma",
      email: "anita@example.com",
      role: "HR Manager",
      department: "HR",
    },
  ]);

  const handleCreate = () => {
    navigate("addEmployee");
  };

  const handleView = (employee: Employee) => {
    console.log("View employee", employee);
    navigate(`viewEmployee/${employee.id}`);
  };

  const handleEdit = (employee: Employee) => {
    console.log("Edit employee", employee);
    navigate(`editEmployee/${employee.id}`);
  };

  const handleDelete = (id: number) => {
    setEmployees((prev) => prev.filter((emp) => emp.id !== id));
  };

  return (
    <div className="max-w-6xl mx-auto mt-10">
      {/* 👇 Show list ONLY if no child route */}
      {!outlet && (
        <EmployeeList
          employees={employees}
          onCreate={handleCreate}
          onView={handleView}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      )}

      {/* 👇 Child pages replace list */}
      <Outlet />
    </div>
  );
};

export default EmployeePage;
