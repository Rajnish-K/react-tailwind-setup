const ViewEmployee: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto mt-10 p-6 bg-white rounded-xl shadow">        
      <h2 className="text-xl font-semibold text-gray-800 mb-4">View Employee</h2>
      {/* Form fields would go here */}
    </div>
  );
};
export default ViewEmployee;