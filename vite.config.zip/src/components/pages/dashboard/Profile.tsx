export default function Profile() {
  return <div>User Profile Page</div>;
}