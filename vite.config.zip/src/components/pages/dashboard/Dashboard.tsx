import { useEffect, useState } from "react";
import useCounter from "../../../custom_hooks/useCounter";
import useDebounce from "../../../custom_hooks/useDebounce";
import { CardDemo } from "../../module1/CardDemo";

export default function Dashboard() {
  const [value, setValue] = useState("");
  const delay = 1000; // milliseconds
  const { increment, decrement, reset, count } = useCounter(0);

  const debouncedValue = useDebounce(value, delay);

  const fetchData = async (query: string) => {
    try {
      const response = await fetch(`https://api.example.com/search?q=${query}`);  
      const data = await response.json();
      console.log("Fetched Data:", data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } 
  }

  useEffect(
    () => {
    if (debouncedValue) {
      console.log("Debounced Value:", debouncedValue);
      fetchData(debouncedValue);
    }
  },
  [debouncedValue]);
  



  return (<>
  <div>Welcome to Dashboard!</div>
  <button onClick={increment}>Increment</button>
  <button onClick={decrement}>Decrement</button>
  <button onClick={reset}>Reset</button>
  <div>Count: {count}</div>

<input type="text" value={value} onChange={(e) => setValue(e.target.value)} placeholder="Type something..." />
  
  <CardDemo />
  </>)
}