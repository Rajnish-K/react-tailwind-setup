
// import { Breadcrumbs } from "./breadcrumb";
import { Breadcrumbs } from "./Breadcrumb";
import { Sidebar } from "./Sidebar";
import { Outlet } from "react-router-dom";

export function Layout() {
  console.log("Layout rendered");
  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-4">
        <Breadcrumbs />
        <Outlet />
      </main>
    </div>
  );
}
