// import React from "react";
// import { Link, useLocation } from "react-router-dom";
// // import { routerConfig } from "@/routes/routerConfig";
// import { Home } from "lucide-react";
// import { routerConfig } from "../routes/router";
// // import { Separator } from "@/components/ui/separator";


// interface RouteItem {
//   path: string;
//   label?: string;
//   breadcrumbLabel?: string;
//   element?: React.ReactNode;
//   children?: RouteItem[];
// }

// const matchRoutePath = (
//   routePath: string,
//   urlParts: string[]
// ): number | null => {
//   const routeParts = routePath.split("/");

//   if (routeParts.length > urlParts.length) return null;

//   for (let i = 0; i < routeParts.length; i++) {
//     const routePart = routeParts[i];
//     const urlPart = urlParts[i];

//     if (routePart.startsWith(":")) continue;
//     if (routePart !== urlPart) return null;
//   }

//   return routeParts.length; // 👈 how many URL parts were consumed
// };

// const findBreadcrumbPath = (
//   routes: RouteItem[],
//   parts: string[]
// ): RouteItem[] | null => {
//   for (const route of routes) {
//     const consumed = matchRoutePath(route.path, parts);

//     if (consumed !== null) {
//       const remaining = parts.slice(consumed);

//       if (remaining.length === 0) {
//         return [route];
//       }

//       if (route.children) {
//         const childPath = findBreadcrumbPath(route.children, remaining);
//         if (childPath) {
//           return [route, ...childPath];
//         }
//       }
//     }
//   }
//   return null;
// };


// export const Breadcrumbs: React.FC = () => {
//   const location = useLocation();
//   const parts = location.pathname.split("/").filter(Boolean);

//   const appRoutes =
//     routerConfig.find((r) => r.path === "/app")?.children || [];

//   const breadcrumbPath =
//     findBreadcrumbPath(appRoutes, parts.slice(1)) || [];

//     console.log("Breadcrumb Path:", breadcrumbPath);

//   if (!breadcrumbPath.length) return null;

//   return (
//     <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
//       <Link
//         to="/app/dashboard"
//         className="flex items-center hover:text-blue-600"
//       >
//         <Home size={16} className="mr-1" />
//         Home
//       </Link>

//       {breadcrumbPath.map((crumb, index) => {
//         const isLast = index === breadcrumbPath.length - 1;

//         const hasLabeledChildren =
//     crumb.children?.some((child) => child.label) ?? false;

//         const label =
//           crumb.breadcrumbLabel || crumb.label || crumb.path;

//         const linkPath = `/app/${breadcrumbPath
//           .slice(0, index + 1)
//           .map((c) => c.path.replace(/\/:.+$/, "")) // remove :id
//           .join("/")}`;

//         return (
//           <React.Fragment key={index}>
//             <span>/</span>
//             {isLast || hasLabeledChildren ? (
//               <span className="font-semibold text-gray-900">{label}</span>
//             ) : (
//               <Link to={linkPath} className="hover:text-blue-600">
//                 {label}
//               </Link>
//             )}
//           </React.Fragment>
//         );
//       })}
//     </nav>
//   );
// };

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home } from "lucide-react";
import { routerConfig } from "../routes/router";

interface RouteItem {
  path?: string;
  label?: string;
  breadcrumbLabel?: string;
  index?: boolean;
  children?: RouteItem[];
}

/* -------------------------------------------
   Match route path with URL parts
-------------------------------------------- */
const matchRoutePath = (
  routePath: string,
  urlParts: string[]
): number | null => {
  const routeParts = routePath.split("/");

  if (routeParts.length > urlParts.length) return null;

  for (let i = 0; i < routeParts.length; i++) {
    if (routeParts[i].startsWith(":")) continue;
    if (routeParts[i] !== urlParts[i]) return null;
  }

  return routeParts.length;
};

/* -------------------------------------------
   Find breadcrumb chain
-------------------------------------------- */
const findBreadcrumbPath = (
  routes: RouteItem[],
  parts: string[]
): RouteItem[] | null => {
  for (const route of routes) {
    // 👇 index route
    if (route.index) {
      if (parts.length === 0) {
        return [route];
      }
      continue;
    }

    if (!route.path) continue;

    const consumed = matchRoutePath(route.path, parts);
    if (consumed === null) continue;

    const remaining = parts.slice(consumed);

    if (remaining.length === 0) {
      return [route];
    }

    if (route.children) {
      const childPath = findBreadcrumbPath(route.children, remaining);
      if (childPath) {
        return [route, ...childPath];
      }
    }
  }
  return null;
};

/* -------------------------------------------
   Breadcrumb Component
-------------------------------------------- */
export const Breadcrumbs: React.FC = () => {
  const location = useLocation();

  // remove empty parts
  const parts = location.pathname.split("/").filter(Boolean);

  // routes under /app
  const appRoutes =
    routerConfig.find((r) => r.path === "/app")?.children || [];

  // skip "app" in URL
  const breadcrumbPath =
    findBreadcrumbPath(appRoutes, parts.slice(1)) || [];

  if (!breadcrumbPath.length) return null;

  return (
    <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
      {/* Home */}
      <Link to="/app" className="flex items-center hover:text-blue-600">
        <Home size={16} className="mr-1" />
        Home
      </Link>

      {breadcrumbPath.map((crumb, index) => {
        const isLast = index === breadcrumbPath.length - 1;

        const label =
          crumb.breadcrumbLabel || crumb.label || "";

        // build link path
        const linkPath =
          "/app/" +
          breadcrumbPath
            .slice(0, index + 1)
            .map((c) =>
              c.path
                ? c.path.replace(/\/?:.+$/, "") // remove :id
                : ""
            )
            .filter(Boolean)
            .join("/");

        const hasChildren = !!crumb.children?.length;

        return (
          <React.Fragment key={index}>
            <span>/</span>

            {isLast || hasChildren ? (
              <span className="font-semibold text-gray-900">
                {label}
              </span>
            ) : (
              <Link to={linkPath} className="hover:text-blue-600">
                {label}
              </Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};


