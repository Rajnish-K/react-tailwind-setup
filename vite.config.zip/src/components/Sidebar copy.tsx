import { Link, useLocation } from "react-router-dom";
import { useState } from "react";
import { routerConfig } from "../routes/router";

interface SidebarChildProps {
  index?: boolean;
  element?: React.ReactNode;
  label?: string;
  path?: string;
  children?: SidebarChildProps[];
}

interface SidebarItemProps {
  item: SidebarChildProps;
  basePath?: string;
}

function SidebarItem({ item, basePath = "" }: SidebarItemProps) {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const fullPath: string = item?.path
    ? `${basePath}/${item.path}`.replace(/\/+/, "/")
    : basePath;

  const isActive = location.pathname.startsWith(fullPath);

  return (
    <li>
      {item?.children ? (
        <div>
          <button
            className={`w-full text-left block ${
              isActive ? "font-bold text-yellow-300" : "font-bold text-indigo-500"
            }`}
            onClick={() => setOpen(!open)}
          >
            {item.label}
          </button>
          {open && (
            <ul className="ml-4 space-y-1">
              {item.children.map((child: SidebarChildProps, i: number) => (
                <SidebarItem key={i} item={child} basePath={fullPath} />
              ))}
            </ul>
          )}
        </div>
      ) : (
        <Link
          to={fullPath}
          className={`block ${isActive ? "font-bold text-yellow-300" : ""}`}
        >
          {item?.label}
        </Link>
      )}
    </li>
  );
}

export function Sidebar() {
  // Grab protected children from root "/"
  const protectedRoutes = routerConfig.find((r) => r.path === "/")?.children;

  // Only render items with label
  const menuItems = protectedRoutes?.filter((item) => item.label);

  return (
    <aside className="w-64 bg-gray-900 text-white p-4 space-y-4">
      <nav>
        <ul className="space-y-2">
          {menuItems?.map((item, i) => (
            <SidebarItem key={i} item={item} basePath="" />
          ))}
          <li>
            <button
              className="text-red-400"
              onClick={() => {
                localStorage.clear();
                location.href = "/login";
              }}
            >
              Logout
            </button>
          </li>
        </ul>
      </nav>
    </aside>
  );
}
