import { format, parse } from "date-fns";

export const DATE_FORMAT = "dd-MM-yyyy";

export const formatDate = (date: Date) => format(date, DATE_FORMAT);

export const parseDate = (dateString: string) =>
  parse(dateString, DATE_FORMAT, new Date());
